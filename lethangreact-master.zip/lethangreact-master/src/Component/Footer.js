import React from 'react'

export default function Footer() {
    return (
        <div className="text-center">
          <span>Copyright @@ 2021</span><span className="text-footer">Devfast</span>
        </div>
    )
}
